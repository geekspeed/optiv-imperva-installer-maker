#!/bin/sh
AGENT_BSX_NAME_IN_ZIP=Imperva-ragent-RHEL-v5-kPAE-pi386-b11.5.0.2032.bsx
INSTALLER_BSX_NAME_IN_ZIP=Imperva-ragentinstaller-RHEL-v5-kPAE-pi386-b1.0.0.5009.bsx
AGENT_VERSION_IN_ZIP=11.5.0.2032
INSTALLER_VERSION_IN_ZIP=1.0.0.5009

# Run the script from the directory it is located in
SOURCE="${0}"
cd `dirname $SOURCE`
ARGUMENT_EXTRACT_DIR=`pwd`

is_kabi_required()
{
    # Get the kabi file value in metadata file: yes/no to declare if kabi is required as a parameter for the install.sh script
	IS_KABI_IN_METADATA=`cat agent.metadata | grep component.hw.kabi | awk -F"=" '{print $2}'`
	if [ $IS_KABI_IN_METADATA = yes ]; then
	    return 0
	else
	    return 1
	fi
}

usage ()
{
    echo ""
    echo "Usage:"
	if is_kabi_required; then
		echo "./install.sh -h | -k <KABI_FILE>"
	else
		echo "./install.sh [-h]"
	fi
	
    echo "  -h        Print this help."
    
	if is_kabi_required; then
        echo "  -k <file> Kernel patch description file."
	fi
	
	exit $1
}

#
# Parse arguments
#
while [ -n "$1" ]
do
    switch=$1
    shift
    case $switch in
    -h) usage 0 ;;
    -k) 
	    if is_kabi_required; then
			KABI_FILE=$1
			if [ -z "$KABI_FILE" ]; then
				usage 1
			fi
			if echo $KABI_FILE | grep -v '^/' > /dev/null; then # if the file is given in a relative path
				KABI_FILE=`pwd`/$KABI_FILE
			fi
			export KABI_FILE
			shift
		else
			usage 1
		fi
		;;
	*) usage 1 ;;
	esac
done

if is_kabi_required && [ -z "$KABI_FILE" ]; then
    echo "Missing mandatory parameter -k"
	usage 1
fi

if [ ! -f ${ARGUMENT_EXTRACT_DIR}/${INSTALLER_BSX_NAME_IN_ZIP} ] && [ ! -f ${ARGUMENT_EXTRACT_DIR}/${AGENT_BSX_NAME_IN_ZIP} ]; then
    echo "Either Agent Installation Manager bsx or Remote Agent bsx files could not be located under ${ARGUMENT_EXTRACT_DIR}."
	exit 1
fi

FAILED_TO_INSTALL_AGENT=false

echo "Checking if the Remote Agent should be installed or upgraded:"

# Run the Installer bsx file with -q parameter to query if Agent is installed or not
${ARGUMENT_EXTRACT_DIR}/${INSTALLER_BSX_NAME_IN_ZIP} -q ragent $AGENT_VERSION_IN_ZIP
RES=$?
if [ $RES -eq 2 ]; then # Agent is not installed -> install it now
    echo ""
	echo "Remote Agent is not installed. Installing Remote Agent."
	if [ -n "$KABI_FILE" ]; then
		${ARGUMENT_EXTRACT_DIR}/${AGENT_BSX_NAME_IN_ZIP} -k "$KABI_FILE"
	else
		${ARGUMENT_EXTRACT_DIR}/${AGENT_BSX_NAME_IN_ZIP}
	fi
	if [ $? -ne 0 ]; then
        echo ""
        echo "Failed to install the Remote Agent."
        exit 1
    fi
elif [ $RES -eq 3 ]; then # Agent is installed and needs to be upgraded
    if [ -n "$KABI_FILE" ]; then
	    ${ARGUMENT_EXTRACT_DIR}/${AGENT_BSX_NAME_IN_ZIP} -u -k "$KABI_FILE"
    else
	    ${ARGUMENT_EXTRACT_DIR}/${AGENT_BSX_NAME_IN_ZIP} -u
	fi
	if [ $? -ne 0 ]; then
        echo ""
        echo "Failed to upgrade the Remote Agent."
        exit 1
    fi
elif [ $RES -eq 1 ]; then
    echo ""
    echo "Failed to get information regarding currently installed Remote Agent."
    exit 1
elif [ $RES -eq 4 ]; then
    echo ""
    echo "Upgrade is not supported for Remote Agent version smaller than 10.0"
	echo "Please uninstall that Remote Agent manually and then perform a clean install." 
	exit 1
elif [ $RES -eq 6 ]; then
    echo ""
	echo "Upgrade is not supported, because the installed Remote Agent version is lower than 7.5"
	echo "Please uninstall that Remote Agent manually and then perform a clean install."
	exit 1
else # return value is 5
    echo ""
    echo "The installed Remote Agent version is equal or higher than the current Remote Agent."
    echo "Nothing to do."
fi

echo ""
echo ""
echo "***************************************************************************"
echo "Checking if the Agent Installation Manager should be installed or upgraded:"
${ARGUMENT_EXTRACT_DIR}/${INSTALLER_BSX_NAME_IN_ZIP} -q ragentinstaller $INSTALLER_VERSION_IN_ZIP
RES=$?
if [ $RES -eq 2 ]; then # Installer is not installed    
    ${ARGUMENT_EXTRACT_DIR}/${INSTALLER_BSX_NAME_IN_ZIP} -x # Install the installer with the Agent configuration
elif [ $RES -eq 3 ]; then # Installer is installed and needs to be upgraded
    ${ARGUMENT_EXTRACT_DIR}/${INSTALLER_BSX_NAME_IN_ZIP} -u
elif [ $RES -eq 1 ]; then
    echo ""
    echo "Failed to get version details of the installed Agent Installation Manager."
    exit 1
elif [ $RES -eq 4 ]; then
    echo ""
    echo "Upgrade is not supported for Agent Installation Manager version smaller than 10.0"
	echo "Please uninstall that Agent Installation Manager manually and then perform a clean install." 
	exit 1
else # return value is 5
    echo ""
    echo "The installed Agent Installation Manager version is equal or higher than the current Agent Installation Manager version."
	echo "Nothing to do."
fi	
